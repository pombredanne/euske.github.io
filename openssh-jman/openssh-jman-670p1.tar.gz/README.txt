-*- coding: utf-8 -*-
README.txt

OpenSSH の日本語マニュアルです。

このディレクトリに含まれているすべてのファイルは、
OpenSSH 本体と同じ (BSD) ライセンスで利用できます。

翻訳: (ほとんどは) 新山祐介 yusuke at cs dot nyu. dot edu

最新版入手先:
http://euske.github.io/openssh-jman/index.html
